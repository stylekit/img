import Foundation
/**
 * NOTE: Unlike Container, section can have a style applied
 * NOTE: you dont need anything in this method actually, the getClassType works if Section is the last SubClass in the subclass hierarchy
 * TODO: make this as an typealias instead
 */
class Section:Element {}