import Foundation
/**
 * NOTE: this class could probably be an alias, is it purly exists to differentiate between types in css
 */
class RadioBullet:SelectButton {}