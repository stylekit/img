import Foundation

protocol ITreeListItem:ITreeList{
    func open()
    func close()
}