import Foundation

class ScrollWheelEvent:Event{
    static let enter:String = "scrollWheelEnter"//Possibly rename to engage
    static let exit:String = "scrollWheelExit"//Possibly rename to disEngage
    static let exitAndStationary:String = "scrollWheelExitAndStationary"
}