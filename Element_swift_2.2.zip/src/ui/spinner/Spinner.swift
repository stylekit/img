import Foundation

class Spinner:Element{}//TODO: write an alias instead