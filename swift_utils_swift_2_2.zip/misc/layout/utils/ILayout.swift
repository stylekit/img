/**
 * TODO: the ILayout classes could probably be simplified with use of class generics 
 */
protocol ILayout{
    init(_ params:Any...)
}