import Foundation

class PrimitiveCirc {
    var x:CGFloat = 0
    var y:CGFloat = 0
    var radius:CGFloat = 0
    init(_ x:CGFloat = 0,_ y:CGFloat = 0, _ radius:CGFloat = 0) {
        self.x = x
        self.y = y
        self.radius = radius
    }
}