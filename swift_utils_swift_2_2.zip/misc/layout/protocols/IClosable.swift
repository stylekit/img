import Foundation

protocol IClosable {
    func close()
}