import Cocoa
//delete!
/*class CustomLayer : CustomCALayer{
    
    override func hitTest(p: CGPoint) -> CALayer? {
    return nil
    }
    
}
*/