import Cocoa
//todo rename to convertPointToView etc. dont use the hiTest prefix
extension NSView {
    /**
     * Asserts if locationInWindow is within the NSView frame
     * NOTE: seem to work different if the view isnt flipped (which some arent) try the alternate method with the "fromView" param
     * TODO: upgrade the type with a generic
     */
    func hitTestToView(locationInWindow:NSPoint, _ toView:NSView? = nil)->Bool{
        let mousePos:NSPoint = convertPoint(locationInWindow, toView: toView)
        /*
        Swift.print("hitTestToView.locationInWindow: " + String(locationInWindow))
        Swift.print("hitTestToView.mousePos(): " + String(mousePos))
        Swift.print("hitTestToView.frame: " + String(frame))
        */
        return NSPointInRect(mousePos, frame)
    }
    /**
     * TODO: upgrade the type with a generic
     */
    func hitTestFromView(locationInWindow:NSPoint, _ fromView:NSView? = nil)->Bool{
        let mousePos:NSPoint = convertPoint(locationInWindow, fromView: fromView)
        /*
        Swift.print("hitTestFromView.locationInWindow: " + String(locationInWindow))
        Swift.print("hitTestFromView.mousePos(): " + String(mousePos))
        Swift.print("hitTestFromView.frame: " + String(frame))
        */
        return NSPointInRect(mousePos, frame)
    }
    /**
     * TODO: upgrade the type with a generic
     */
    func hitTestFromViewRelativeToFrame(locationInWindow:NSPoint, _ fromView:NSView? = nil)->Bool{
        let mousePos:NSPoint = convertPoint(locationInWindow, fromView: fromView)/*converts the mouse pos from a wrongly flipped view to a correctly flipped view*/
        Swift.print("hitTestFromView.locationInWindow: " + String(locationInWindow))
        Swift.print("hitTestFromView.mousePos(): " + String(mousePos))
        Swift.print("hitTestFromView.frame: " + String(frame))
        /**/
        return NSPointInRect(mousePos + frame.origin, frame)
    }
    /**
     * Convenince method that returns the view aswell (by utilising generics)
     */
    func addSubView<T:NSView>(view: T)->T{
        self.addSubview(view)
        return view
    }
    /**
     *
     */
    func addSubViewAt<T:NSView>(view:T, _ i:Int)->T{
        ViewModifier.addSubviewAt(self, view, i)
        return view
    }
    /**
     * TODO: You can probably deprecated this
     */
    func addSubviewAt<T:NSView>(view: T,_ i:Int){
        //Swift.print("\(self.dynamicType)" + ".addSubviewAt() i: " + "\(i)")
        ViewModifier.addSubviewAt(self, view, i)
    }
    /**
     * TODO: Probably upgrade this to use Generics and deprecate it
     */
    func removeSubviewAt(i:Int){
        ViewModifier.removeSubviewAt(self, i)
    }
    /**
     * Asserts if @param view is a subView of @param parent
     */
    func contains<T:NSView>(view:T)->Bool{
        return NSViewAsserter.contains(self, view)
    }
    var point:CGPoint {get{return frame.origin} set{frame.origin = newValue}}/*you cant have setPoint() as  a method by having this variable here, something to keep in mind*///pos is occupied by another class
    
    //var width:CGFloat{return frame.width}//TODO:implement later
    //var height:CGFloat{return frame.height}
    /**
     * Returns localPosition in a view (converts a global position to a local position)
     * TODO: hopefully this method also works if the view is not 0,0 in the window
     */
    /**
     * Returns the local mouse position in the views coordinate system 0,0
     */
    func localPos()->CGPoint{
        return self.convertPoint((window?.mouseLocationOutsideOfEventStream)!,fromView:nil)
    }
    /**
     * IMPORTANT: You may need to y-flip this point
     */
    func globalPoint()->CGPoint{
        return (window?.mouseLocationOutsideOfEventStream)!
    }
    /**
     *
     */
    func indexOf<T:NSView>(subView:T)->Int{
        return NSViewParser.indexOf(self, subView)
    }
    /**
     * Returns a localPoint (UNTESTED)
     */
    func globalToLocal(p:CGPoint) -> CGPoint{
        return convertPoint(p, fromView:self)
    }
    /**
     * Returns a globalPoint (UNTESTED)
     */
    func localToGlobal(p:CGPoint) -> CGPoint{
        return convertPoint(p, toView:self)
    }
    var mouseX:CGFloat{return MouseUtils.point(self).x}/*UNTESTED*/
    var mouseY:CGFloat{return MouseUtils.point(self).y}/*UNTESTED*/
    /**
     * DEPRECATED
     */
    func getSubviewAt(i:Int)->NSView{return NSViewParser.getSubviewAt(self, i)}//favour getSubViewAt method instead, as its optional
    func getSubViewAt(i:Int)->NSView?{return NSViewParser.getSubViewAt(self, i)}
    var numSubViews:Int {return subviews.count}/*convenience*/
    var w:CGFloat{get{return frame.width}set{frame.width = newValue}}//aperantly .width is used too may places, you need to refactor it out first, same with height
    var h:CGFloat{get{return frame.height}set{frame.height = newValue}}
    var x:CGFloat{get{return frame.origin.x}set{frame.origin.x = newValue}}
    var y:CGFloat{get{return frame.origin.y}set{frame.origin.y = newValue}}
}