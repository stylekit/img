class SQLLiteAsserter{
	//add legacy code when needed	
}