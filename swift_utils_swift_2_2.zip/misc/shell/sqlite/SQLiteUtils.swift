class SQLLiteUtils{
	//add legacy code when needed
}