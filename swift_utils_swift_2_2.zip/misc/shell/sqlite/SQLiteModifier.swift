class SQLLiteModifier{
	//add legacy code when needed
}