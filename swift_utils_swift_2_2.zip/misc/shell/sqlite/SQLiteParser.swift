class SQLLiteParser{
	//add legacy code when needed
}