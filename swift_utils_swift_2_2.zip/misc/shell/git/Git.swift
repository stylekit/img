import Foundation

class Git {
    static var path:String = "/usr/local/git/bin/"/*To execute git commands we need to call the git commands from this path*/
}