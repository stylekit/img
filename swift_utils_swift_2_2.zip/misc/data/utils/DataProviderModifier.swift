import Foundation
class DataProviderModifier {
    /**
     * Adds an item to PARAM: dataProvider at an array index PARAM: index
     */
    static func addItemAtIndex(dataProvider:DataProvider,_ index:Array<Int>,_ item:Dictionary<String,String>)->DataProvider{
        //see legacy code for instructions on how to implement this
        fatalError("not implemented yet")
        //return DataProvider()
    }
}