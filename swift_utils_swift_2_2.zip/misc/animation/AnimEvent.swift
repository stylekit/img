import Foundation
class AnimEvent:Event{
    static let completed:String = "animCompleted"
    static let stopped:String = "animStopped"
}