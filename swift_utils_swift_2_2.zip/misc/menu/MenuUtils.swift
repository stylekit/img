import Foundation

class MenuUtils {
	//unCheckAll -> See legacy code
	//getItemByLabel -> See legacy code
}