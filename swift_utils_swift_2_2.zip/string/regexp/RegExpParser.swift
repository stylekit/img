import Foundation

public class RegExpParser{
	/*
	Add these from legacy:
	
	match,
	associatedMatch,
	urlProtocol,
	contentBetweenTitleTags,
	usPrices,
	nonUsPrices,
	lowerCaseWordsWithinRange,
	lowerCaseWords,
	lowerCaseWordsWithExecution,
	emails,
	words,
	wordsThatStartSubseedAndEndWith,
	sentences,
	rgbHexaDecimals,
	computerDate,
	htmlLinks,
	indexOfWordStartingWith,
	split,
	usZipCodes,
	cssProperties;/*Great example off associative and array use*/
	
	
	*/
}