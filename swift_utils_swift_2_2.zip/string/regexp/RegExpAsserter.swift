import Foundation

public class RegExpAsserter{
	//Add these methods from legacy code:
	//test,
	//hasLowerCase,
	//hasDigit,
	//isSVGDocument;
}