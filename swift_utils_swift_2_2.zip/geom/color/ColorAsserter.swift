import Foundation

class ColorAsserter {
    /**
     * PARAM: string ("both 0x00ff00" and "0x00f" will return true)
     */
    static func isColor(string:String)->Bool {
        return RegExp.test(string, "^0x?([a-fA-F0-9]{3}){1,2}$")
    }
}