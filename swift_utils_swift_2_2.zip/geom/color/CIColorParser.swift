import Cocoa

class CIColorParser {
  /*implement this when it's needed*/
}