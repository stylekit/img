import Foundation
/**
 * Interface for SVGView
 */
protocol ISVGView:ISVGElement{
    var style:SVGStyle?{get set}
}