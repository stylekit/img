import Foundation

class SVGAsserter {
    /**
     * Asserts if a point is within the SVG (empty holes will return false)
     */
    static func isPointWithin(svg:SVG){
        //CGPathContainsPoint(path,transform,point)
        Swift.print("complete this method when needed")
    }
}