import Foundation
/**
 * Interface for SVGElement
 */
protocol ISVGElement {
    var id:String  {get set}
}