import Foundation
/**
 * Interface for the SVGPolyLine class
 */
protocol ISVGPolyLine {
    var points:Array<CGPoint> {get set}
}