import Foundation

class CGLineParser {
}