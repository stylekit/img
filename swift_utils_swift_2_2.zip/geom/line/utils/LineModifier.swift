import Foundation

class CGLineModifier {
}