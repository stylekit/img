import Foundation

class FillStyleModifier {
}