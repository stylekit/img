import Foundation
/*
 * NOTE: It may be tempting to make variables of each of these types, don't its just more code
 */
class TextFieldConstants {
    static var textFieldPropertyNames:[String] = ["alwaysShowSelection","antiAliasType","autoSize","alpha","background","backgroundColor","border","borderColor","condenseWhite","displayAsPassword","embedFonts","gridFitType","height","htmlText","maxChars","mouseWheelEnabled","mouseEnabled","multiline","restrict","sharpness","selectable","thickness","type","textColor","useRichTextClipboard","width","wordWrap"]
}