class TrigModifier {
}