class IntAsserter {
    /**
     * NOTE: In most cases you will want to write if(someNumber < 0)
     */
    static func negative(number:Int) -> Bool{
        return number < 0
    }
    /**
     * NOTE: In most cases you will want to write if(someNumber >
     */
    static func positive(number:Int)->Bool {
        return number > 0
    }
}