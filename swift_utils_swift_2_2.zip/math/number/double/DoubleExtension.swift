import Foundation

extension Double {
    var cgFloat:CGFloat {return CGFloat(self)}/*Convenince*/
}