import Foundation

extension Float {
    var int:Int{return Int(self)}
    var cgFloat:CGFloat {return CGFloat(self)}/*Convenince*/
    var double:Double {return Double(self)}/*Convenince*/
}